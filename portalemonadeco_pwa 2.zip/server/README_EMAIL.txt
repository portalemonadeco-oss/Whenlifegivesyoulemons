Email setup notes:
- For Gmail (test only), you may need to create an App Password and use SMTP with host 'smtp.gmail.com', port 587.
- For production, use SendGrid or Mailgun and set SMTP credentials in environment variables.
- Set ORDER_EMAIL env var to portalemonadeco@gmail.com
