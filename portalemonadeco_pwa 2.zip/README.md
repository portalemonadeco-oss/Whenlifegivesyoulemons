# Port A Lemonade Co. - PWA Prototype

This is a progressive web app (PWA) prototype for **Port A Lemonade Co.** — bright & beachy design.

## What is included
- Frontend PWA in the root folder (index.html, styles.css, app.js)
- Simple service worker (sw.js) and manifest.json to enable "Add to Home Screen"
- Admin page (admin.html) that reads demo orders from localStorage
- Placeholder images in `/images/`
- Optional Node server template in `/server` (create Stripe checkout sessions and send order emails)

## Demo behavior (no server)
- Orders placed in the demo are saved to the browser's `localStorage`.
- Admin page (admin.html) displays saved orders on the device that created them.
- A real email to `portalemonadeco@gmail.com` will NOT be sent until you deploy a server and configure email sending (instructions below).

## To run locally
1. Unzip the package.
2. With any simple static host (VS Code Live Server, `python -m http.server`, or upload to Glitch) open `index.html`.
3. To test PWA install behavior on iPhone: open Safari → open the URL (e.g. from Glitch) → tap Share → "Add to Home Screen".

## Deploy to Glitch (free)
1. Create a free account at https://glitch.com.
2. Create a new "hello-webpage" project.
3. Delete default files and upload the contents of this ZIP.
4. Set your project to public and note the project URL (e.g. `portalemonadeco.glitch.me`).

## Connecting Stripe (optional, for real payments)
- For security, Stripe requires creating Checkout Sessions from a server (Node example provided in `/server`).
- Add your Stripe Secret Key to the server environment and your Publishable Key to the frontend (in the client you can configure a variable).
- The `server/server.js` file is a simple Express app that creates Checkout Sessions and shows how to handle webhooks to mark orders and send emails.

## Email notifications
- The included server uses `nodemailer` with SMTP placeholders. You can:
  - Use Gmail SMTP (for low-volume testing) — see server/README_EMAIL.txt inside the ZIP for Gmail setup.
  - Use SendGrid or Mailgun (recommended) — set credentials in environment variables.

## What to change for your brand
- Replace `/images/*` with real photos.
- Customize copy in `index.html`.
- Add your Stripe keys and deploy the server to Glitch or Heroku.

## Quick notes about the app behavior
- Tagline: "When life gives you lemons… bring them to Port A Lemonade Co."
- Pickup location: Port Aransas, TX
- Contact email (for admin): portalemonadeco@gmail.com
- Pricing: Classic Lemonade $9.00, Flavor Add-On +$1.00

Enjoy! If you want, I can also:
- Prepare the Glitch project steps verbatim to copy/paste.
- Customize visuals (icons and photos) with beachy replacements.
- Generate a ready-to-run Glitch project with server (if you give me permission to create a public GitHub repo next).
