// Frontend PWA demo logic. Orders are stored in localStorage for demo.
const state = {cart:[]};

function $(sel){return document.querySelector(sel)}
function $all(sel){return document.querySelectorAll(sel)}

function show(id){ ['home','menu','thanks'].forEach(i=>document.getElementById(i)?.classList.add('hidden')); document.getElementById(id).classList.remove('hidden') }
function enableCheckout(){ $('#checkoutBtn').disabled = state.cart.length === 0; }

document.addEventListener('DOMContentLoaded',()=>{
  $('#orderNow').addEventListener('click',()=>{ $('#home').classList.add('hidden'); $('#menu').classList.remove('hidden'); });
  $all('.addBtn').forEach(b=>{
    b.addEventListener('click', e=>{
      const item = e.target.dataset.item;
      let qty = 1;
      if(item==='classic') qty = parseInt($('#qtyClassic').value||1);
      if(item==='addon') qty = parseInt($('#qtyAddon').value||0);
      if(qty<=0) return;
      if(item==='classic') state.cart.push({id:'classic',name:'Classic Lemonade',price:9.00,qty});
      if(item==='addon') state.cart.push({id:'addon',name:'Flavor Add-On',price:1.00,qty});
      renderCart();
    });
  });

  $('#checkoutBtn').addEventListener('click',()=>{
    $('#menu').classList.add('hidden');
    $('#checkout').classList.remove('hidden');
  });

  $('#placeOrder').addEventListener('click',()=>{
    const name = $('#custName').value||'Guest';
    const phone = $('#custPhone').value||'';
    const flavor = $('#flavorChoice').value||'None';
    const order = {
      id: 'order-'+Date.now(),
      name, phone, flavor,
      items: state.cart,
      total: state.cart.reduce((s,i)=>s+i.price*i.qty,0),
      created: new Date().toISOString()
    };
    // save to orders in localStorage
    const orders = JSON.parse(localStorage.getItem('pa_orders')||'[]');
    orders.push(order);
    localStorage.setItem('pa_orders', JSON.stringify(orders));
    // clear cart
    state.cart = [];
    renderCart();
    $('#checkout').classList.add('hidden');
    $('#orderSummary').innerText = `Order ${order.id} — ${order.items.length} line(s). Total: $${order.total.toFixed(2)}. Pickup at Port Aransas, TX.`;
    $('#thanks').classList.remove('hidden');
    // NOTE: To send a real email to portalemonadeco@gmail.com, enable server email (see README).
  });

  $('#backHome').addEventListener('click',()=>{ $('#thanks').classList.add('hidden'); $('#home').classList.remove('hidden'); });

  $('#cartItems').addEventListener('click', (e)=>{
    if(e.target.matches('.remove')) {
      const idx = parseInt(e.target.dataset.idx);
      state.cart.splice(idx,1);
      renderCart();
    }
  });

  // initialize
  renderCart();
});

function renderCart(){
  const el = $('#cartItems');
  if(state.cart.length===0){ el.innerHTML='Cart is empty'; $('#checkoutBtn').disabled=true; return; }
  const rows = state.cart.map((c,i)=>`<div class="cart-row"><strong>${c.name}</strong> x${c.qty} — $${(c.price*c.qty).toFixed(2)} <button class="remove" data-idx="${i}">Remove</button></div>`).join('');
  el.innerHTML = rows;
  $('#checkoutBtn').disabled = false;
}
